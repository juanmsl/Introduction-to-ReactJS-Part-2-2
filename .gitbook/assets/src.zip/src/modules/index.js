import React from 'react';


export default class NewsFeedApp extends React.Component {
  render() {
    return "News Feed App";
  }
}
